// Initialize an empty queue
let customerQueue = [];

// Function to add a customer to the queue
function addCustomer(name) {
    customerQueue.push(name);
    alert("Customer " + name + " is added to number " + customerQueue.length);
}

// Function to service a customer
function serviceCustomer(number) {
    if (number > 0 && number <= customerQueue.length) {
        const customerName = customerQueue[number - 1];
        alert("Servicing customer: " + customerName);
        // Remove the serviced customer from the queue
        customerQueue.splice(number - 1, 1);
        console.log("Updated Queue: [" + customerQueue.join(", ") + "]");
    } else {
        alert("Invalid number.");
    }
}

// Main program loop to add customers
for (let i = 0; i < 5; i++) {
    const customerName = prompt("Enter customer's name:");
    addCustomer(customerName);
}

// Service customers
while (customerQueue.length > 0) {
    // Show current queue with numbers
    let queueDisplay = customerQueue.map((name, index) => `${index + 1}: ${name}`).join(", ");
    const serviceNumber = parseInt(prompt("Current Queue: " + queueDisplay + "\nEnter the customer number to be serviced:"));
    serviceCustomer(serviceNumber);
}